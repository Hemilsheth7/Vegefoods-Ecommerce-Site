<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "vege1";
	$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
$search1 = $_POST['search'];


	$sql="SELECT * FROM items WHERE item_name='$search1'";
	$result = mysqli_query($conn,$sql);
    	if($result->num_rows > 0)
    	{
       		header('Location: contact.html');	
    	}
	else
	{
		echo("Error logging in.The username or password does not match");
	}
	


$conn->close();
?>