<?php

$keyId = 'rzp_test_51tN6RMIOxTqMd';
$keySecret = '9sqXqWtspWpw9tLMkl1RDPMZ';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
