    <?php  
    $host = 'localhost:3306';  
    $user = 'root';  
    $pass = '';  
    $dbname = 'hackstomp';  
      
    $conn = mysqli_connect($host, $user, $pass,$dbname);  
    if(!$conn){  
      die('Could not connect: '.mysqli_connect_error());  
    }  
    echo 'Connected successfully<br/>';  
    
    $username = $_POST['uname'];
    $password = $_POST['pass'];
    $fname = $_POST['name'];
    $phoneno = $_POST['number'];
    $email = $_POST['email'];
      

    $sql= "INSERT INTO user VALUES('"$name"','"$username"','"$password"','"$phoneno"','"$email"')";
 
    if(mysqli_query($conn, $sql)){  
     header('Location: index.html');
    }else{  
    echo "Could not insert record: ". mysqli_error($conn);  
    }  
      
    mysqli_close($conn);  
    ?>  